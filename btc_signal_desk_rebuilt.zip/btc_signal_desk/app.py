import streamlit as st
import ccxt
import pandas as pd
import plotly.graph_objects as go

st.set_page_config(page_title="BTC Signal Desk", page_icon="₿", layout="wide")
st.markdown("""
<style>
.stApp{background:#080d16;color:#e8eef8}
section[data-testid="stSidebar"]{background:#0d1522}
.block-container{padding-top:1.1rem;max-width:1500px}
div[data-testid="stMetric"]{background:#111c2b;border:1px solid #26384e;padding:12px;border-radius:12px}
.signal{padding:18px;border-radius:14px;background:#111c2b;border:1px solid #26384e}
.muted{color:#91a4bd;font-size:13px}
</style>""", unsafe_allow_html=True)

st.title("₿ BTC SIGNAL DESK")
st.caption("Live BTC technical dashboard · Public market data · Analysis only — no orders are placed")

with st.sidebar:
    st.header("Controls")
    exchange_name = st.selectbox("Exchange", ["Binance", "Coinbase", "Kraken"])
    symbol = st.selectbox("Market", ["BTC/USDT", "BTC/USD"], index=0 if exchange_name=="Binance" else 1)
    timeframe = st.selectbox("Primary timeframe", ["1m", "5m", "15m"], index=2)
    candle_limit = st.slider("Candles", 100, 500, 250, 25)
    st.caption("If a market/timeframe is unsupported, switch exchange or pair.")

EXCHANGES = {"Binance": ccxt.binance, "Coinbase": ccxt.coinbase, "Kraken": ccxt.kraken}

@st.cache_data(ttl=20, show_spinner=False)
def load_candles(exchange_name, symbol, timeframe, limit):
    exchange = EXCHANGES[exchange_name]({"enableRateLimit": True, "timeout": 15000})
    raw = exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
    df = pd.DataFrame(raw, columns=["timestamp","open","high","low","close","volume"])
    df["time"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
    return df

def add_indicators(df):
    x = df.copy()
    for n in (9, 21, 50, 200):
        x[f"ema{n}"] = x.close.ewm(span=n, adjust=False).mean()
    delta = x.close.diff()
    avg_gain = delta.clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
    avg_loss = (-delta.clip(upper=0)).ewm(alpha=1/14, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, float("nan"))
    x["rsi"] = 100 - 100/(1+rs)
    e12 = x.close.ewm(span=12, adjust=False).mean()
    e26 = x.close.ewm(span=26, adjust=False).mean()
    x["macd"] = e12-e26
    x["macd_signal"] = x.macd.ewm(span=9, adjust=False).mean()
    x["macd_hist"] = x.macd-x.macd_signal
    tr = pd.concat([x.high-x.low, (x.high-x.close.shift()).abs(), (x.low-x.close.shift()).abs()], axis=1).max(axis=1)
    x["atr"] = tr.ewm(alpha=1/14, adjust=False).mean()
    up, down = x.high.diff(), -x.low.diff()
    plus = up.where((up>down)&(up>0), 0.0)
    minus = down.where((down>up)&(down>0), 0.0)
    pdi = 100*plus.ewm(alpha=1/14, adjust=False).mean()/x.atr.replace(0, float("nan"))
    mdi = 100*minus.ewm(alpha=1/14, adjust=False).mean()/x.atr.replace(0, float("nan"))
    dx = 100*(pdi-mdi).abs()/(pdi+mdi).replace(0, float("nan"))
    x["pdi"], x["mdi"] = pdi, mdi
    x["adx"] = dx.ewm(alpha=1/14, adjust=False).mean()
    mid = x.close.rolling(20).mean()
    sd = x.close.rolling(20).std()
    x["bb_mid"], x["bb_upper"], x["bb_lower"] = mid, mid+2*sd, mid-2*sd
    x["vol_avg"] = x.volume.rolling(20).mean()
    return x

def evaluate(x):
    r, p = x.iloc[-1], x.iloc[-2]
    bull = bear = 0
    detail = []
    def record(name, side, pts):
        nonlocal bull, bear
        if side == "Bullish": bull += pts
        elif side == "Bearish": bear += pts
        detail.append({"Indicator": name, "Reading": side, "Points": pts if side != "Mixed" else 0})
    record("EMA 9/21/50 alignment", "Bullish" if r.ema9>r.ema21>r.ema50 else "Bearish" if r.ema9<r.ema21<r.ema50 else "Mixed", 2)
    record("Price vs EMA 50", "Bullish" if r.close>r.ema50 else "Bearish", 1)
    record("MACD momentum", "Bullish" if r.macd>r.macd_signal and r.macd_hist>p.macd_hist else "Bearish" if r.macd<r.macd_signal and r.macd_hist<p.macd_hist else "Mixed", 2)
    record("RSI", "Bullish" if 52<r.rsi<70 else "Bearish" if 30<r.rsi<48 else "Mixed", 1)
    record("DMI direction", "Bullish" if r.pdi>r.mdi else "Bearish" if r.mdi>r.pdi else "Mixed", 1)
    record("ADX trend strength", "Bullish" if r.adx>=20 and r.pdi>r.mdi else "Bearish" if r.adx>=20 and r.mdi>r.pdi else "Mixed", 1)
    record("Volume confirmation", "Bullish" if r.close>r.open and r.volume>r.vol_avg else "Bearish" if r.close<r.open and r.volume>r.vol_avg else "Mixed", 1)
    signal = "UP" if bull>=6 and bull-bear>=3 else "DOWN" if bear>=6 and bear-bull>=3 else "WAIT"
    return signal, bull, bear, detail

try:
    with st.spinner("Fetching BTC market data..."):
        data = add_indicators(load_candles(exchange_name, symbol, timeframe, candle_limit))
    if len(data) < 60:
        st.error("Not enough candle history returned.")
        st.stop()
except Exception as exc:
    st.error(f"Market data could not be loaded: {exc}")
    st.info("Try another exchange or BTC pair. Public endpoints can have rate limits or symbol restrictions.")
    st.stop()

last, prior = data.iloc[-1], data.iloc[-2]
signal, bull, bear, details = evaluate(data)
price = float(last.close)
atr = float(last.atr) if pd.notna(last.atr) else price*0.003
color = "#20c997" if signal=="UP" else "#ff657a" if signal=="DOWN" else "#f5bd4f"

a,b,c,d = st.columns(4)
a.metric("BTC price", f"${price:,.2f}", f"{price-float(prior.close):+,.2f}")
b.metric("Signal", signal, "Technical bias")
c.metric("RSI (14)", f"{last.rsi:.1f}")
d.metric("ADX (14)", f"{last.adx:.1f}")

chart_col, signal_col = st.columns([2.15,1])
with chart_col:
    st.subheader(f"{symbol} · {timeframe}")
    fig = go.Figure()
    fig.add_trace(go.Candlestick(x=data.time, open=data.open, high=data.high, low=data.low, close=data.close, name="BTC"))
    for col, label, color_line in [("ema9","EMA 9","#f5bd4f"),("ema21","EMA 21","#4ea1ff"),("ema50","EMA 50","#c084fc")]:
        fig.add_trace(go.Scatter(x=data.time, y=data[col], name=label, mode="lines", line=dict(width=1.4,color=color_line)))
    fig.update_layout(template="plotly_dark", height=500, margin=dict(l=5,r=5,t=15,b=5),
                      xaxis_rangeslider_visible=False, paper_bgcolor="#080d16", plot_bgcolor="#080d16",
                      legend=dict(orientation="h",y=1.02))
    st.plotly_chart(fig, use_container_width=True)

with signal_col:
    st.subheader("Signal engine")
    st.markdown(f"""<div class="signal"><div class="muted">CURRENT BIAS</div>
    <div style="font-size:40px;font-weight:800;color:{color}">{signal}</div>
    <div class="muted">Indicator evidence score — not a win probability</div>
    <div style="font-size:25px;font-weight:700">{max(bull,bear)} / 9</div>
    <hr style="border-color:#26384e">
    Bullish points: {bull} · Bearish points: {bear}</div>""", unsafe_allow_html=True)
    st.write("")
    if signal == "UP":
        entry, stop, target = price, price-1.5*atr, price+2*atr
    elif signal == "DOWN":
        entry, stop, target = price, price+1.5*atr, price-2*atr
    else:
        entry = stop = target = None
    if entry is not None:
        st.metric("Reference entry", f"${entry:,.2f}")
        st.metric("ATR invalidation", f"${stop:,.2f}")
        st.metric("Illustrative target", f"${target:,.2f}")
    else:
        st.info("WAIT: no reference trade levels until indicators align.")
    st.caption("ATR levels are estimates, not guaranteed fills or advice.")

st.subheader("Indicator confluence")
st.dataframe(pd.DataFrame(details), hide_index=True, use_container_width=True)

st.subheader("Momentum")
rsi_col, macd_col = st.columns(2)
with rsi_col:
    f = go.Figure(go.Scatter(x=data.time,y=data.rsi,name="RSI",line=dict(color="#4ea1ff")))
    f.add_hline(y=70,line_dash="dash"); f.add_hline(y=30,line_dash="dash")
    f.update_layout(template="plotly_dark",height=230,margin=dict(l=5,r=5,t=10,b=5),paper_bgcolor="#080d16",plot_bgcolor="#080d16",yaxis_range=[0,100])
    st.plotly_chart(f,use_container_width=True)
with macd_col:
    f = go.Figure()
    f.add_trace(go.Bar(x=data.time,y=data.macd_hist,name="Histogram"))
    f.add_trace(go.Scatter(x=data.time,y=data.macd,name="MACD"))
    f.add_trace(go.Scatter(x=data.time,y=data.macd_signal,name="Signal"))
    f.update_layout(template="plotly_dark",height=230,margin=dict(l=5,r=5,t=10,b=5),paper_bgcolor="#080d16",plot_bgcolor="#080d16")
    st.plotly_chart(f,use_container_width=True)

st.subheader("Multi-timeframe confirmation")
multi = []
for tf in ["1m","5m","15m"]:
    try:
        frame = add_indicators(load_candles(exchange_name,symbol,tf,candle_limit))
        sig, up, dn, _ = evaluate(frame)
        multi.append({"Timeframe":tf,"Signal":sig,"Bull points":up,"Bear points":dn,"Close":f"${frame.iloc[-1].close:,.2f}"})
    except Exception:
        multi.append({"Timeframe":tf,"Signal":"Unavailable","Bull points":"—","Bear points":"—","Close":"—"})
st.dataframe(pd.DataFrame(multi),hide_index=True,use_container_width=True)

st.caption(f"Last candle: {last.time.strftime('%Y-%m-%d %H:%M UTC')} · Public exchange data may be delayed or unavailable.")
st.caption("Educational tool only. Crypto is volatile. No live trading, guaranteed signals, or guaranteed push alerts.")
