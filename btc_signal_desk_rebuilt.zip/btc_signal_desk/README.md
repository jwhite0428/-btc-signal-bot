# BTC Signal Desk

Mobile-friendly Streamlit dashboard for BTC technical analysis using public exchange OHLCV data.

## Features
- Dark BTC candlestick dashboard with EMA 9/21/50
- RSI, MACD, ADX/DMI, Bollinger Band calculations
- Weighted UP / DOWN / WAIT confluence score
- ATR-based illustrative invalidation and target levels
- 1m / 5m / 15m multi-timeframe comparison
- No API keys and no live order execution

## Deploy
1. Upload `app.py` and `requirements.txt` to the root of a GitHub repository.
2. In Streamlit Community Cloud, deploy that repository.
3. Set the main file path to `app.py`.

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

Choose an exchange and BTC pair supported by that exchange. For example, Binance commonly supports BTC/USDT, while Coinbase and Kraken commonly support BTC/USD.

This is an educational technical-analysis tool, not financial advice. Indicator scores are not probabilities and ATR levels are not guaranteed fills.
